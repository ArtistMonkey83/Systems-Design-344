#include "tm4c123gh6pm.h"

void PortB_Init(void);

void PortF_Init(void);