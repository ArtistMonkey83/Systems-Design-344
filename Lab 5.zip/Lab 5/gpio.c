#include "gpio.h"
#include <stdint.h>

void PortB_Init(void) {
	SYSCTL_RCGCGPIO_R |= 0x02; //000010
	GPIO_PORTB_DIR_R  |= 0XFF; 
	GPIO_PORTB_DEN_R  |= 0XFF;
}

void PortF_Init(void) { volatile unsigned long delay;
	SYSCTL_RCGCGPIO_R |= 0x20; //10000000
	
	//PORTF0 has special function, need to unlock to modify
	GPIO_PORTF_LOCK_R = 0x4C4F434B;
	GPIO_PORTF_CR_R = 0x01;
	GPIO_PORTF_LOCK_R = 0;
	
	//Configure PortF for switch input
	GPIO_PORTF_DIR_R &= ~0x11;  //F4 & F0 for inputs for switch, 00010001 
	GPIO_PORTF_DEN_R |=0x1F;   //make port4-0 digital pins
	GPIO_PORTF_PUR_R |=0x11;   //enable pull up resistor for PORT4,0
	
  //Port F4,F0 for falling edge trigger interrupt
	GPIO_PORTF_IS_R  &=~ 0x11; //make bit 4,0 edge sensitive
	GPIO_PORTF_IBE_R &=~ 0x11; //trigger is controlled by IEV
	GPIO_PORTF_IEV_R &=~ 0x11; //falling edge trigger
	GPIO_PORTF_ICR_R |=~ 0x11; //clear any prior interupt
	GPIO_PORTF_IM_R  |=~ 0x11; //unmask interrupt
	
	//Enable interrupt in NVIC and set priority to 5
	NVIC_PRI7_R = (NVIC_PRI7_R & 0xFF00FFFF)|(5<<21); //set interrupt priority to 5
	NVIC_EN0_R |= 0x40000000; //Enable IRQ30 (D30 of ISER[0])
	
	__enable_irq(); //global enable IRQs
}