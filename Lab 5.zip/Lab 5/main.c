#include <stdint.h>
#include "PLL.h"
#include "SysTick.h"
#include "tm4c123gh6pm.h"
#include "gpio.h"

uint32_t INPUT = 0;

int main(void){
	//Init PLL
	PLL_Init();
	//Init Systick
	SysTick_Init(); 
	//Init PF and PB 
	PortB_Init();
	PortF_Init();
	 
  while(1){
		int i;
		int p;
		uint8_t Sine[12] = {16,24,30,31,30,24,16,8,2,0,2,8};
   // Ouput depending on the global variable
	 //0
		if(INPUT == 0){
			GPIO_PORTB_DATA_R = 0x00;
		}
	 //1
		if(INPUT == 1){ //SAW: 
			for (p=0;p<32;p++)
			{GPIO_PORTB_DATA_R = p ;
			SysTick_Wait1ms(8);
		}
		}
	 //2 
		{
			{INPUT = 2; //sine
			for (i=0;i<12;i++)
			{
			GPIO_PORTB_DATA_R = Sine[i];
			SysTick_Wait1ms(5);
			}
			}
		}
  }
}
   
//SW1 connected to PF4 pin, SW2 connected to PF0
//Both of them trigger PORTF interrupt
//int INPUT;
void GPIOF_Handler(void){
	
	volatile int readback;
	while (GPIO_PORTF_MIS_R != 0){
	//decide the switch value as input
		if (GPIO_PORTB_MIS_R & 0x10) //Is it SW1(PF4)
		{
		{INPUT = 1; //N/A //saw
		}
		GPIO_PORTF_ICR_R |= 0x10; //Clear the interupt flag before return
		readback = GPIO_PORTF_ICR_R; //a read to force clearing of interrupt flag
		}
		else if (GPIO_PORTF_MIS_R & 0x01) //then it must be SW2
		{
		{INPUT = 2; //N/A //sine
		}
		GPIO_PORTF_ICR_R |= 0x01; //Clear the interupt flag before return
		readback = GPIO_PORTF_ICR_R;//a read to force clearing of interrupt flag
		}
		else //nothing is pressed
		{
		{INPUT = 0; //N/A
		}
		GPIO_PORTF_ICR_R |= 0x11; //Clear the interupt flag before return
		readback = GPIO_PORTF_ICR_R;//a read to force clearing of interrupt flag
		}
	}
}